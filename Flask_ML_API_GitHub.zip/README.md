# Flask ML API with Docker

This repository contains a minimal example of deploying a machine learning model (Linear Regression) as a REST API using Flask and Docker.

## Features

- 🔁 Model trained with scikit-learn
- 🔬 Prediction endpoint using `/predict`
- 🐳 Dockerfile and Docker Compose setup
- ✅ Ready to deploy locally

## Usage

### 1. Clone the repository

```bash
git clone <repo_url>
cd Flask_ML_API_GitHub
```

### 2. Build and run with Docker Compose

```bash
docker compose up --build
```

### 3. Access the API

- Open: [http://localhost:8000](http://localhost:8000)
- Test prediction:

```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{"features": [0.038, 0.05, 0.061, 0.021, -0.044, -0.034, -0.043, -0.002, 0.019, -0.017]}'
```

## License

MIT
